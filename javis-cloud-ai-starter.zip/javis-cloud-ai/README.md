# JAVIS — Cloud AI Starter

Ein dunkler, futuristischer Next.js-Starter für deinen persönlichen KI-Assistenten.

## Lokal starten

1. Node.js 20 oder neuer installieren: https://nodejs.org/
2. Im Projektordner ein Terminal öffnen.
3. `npm install`
4. `.env.example` in `.env.local` kopieren.
5. Die Zugangsdaten eines kompatiblen KI-Anbieters in `.env.local` eintragen.
6. `npm run dev` ausführen und http://localhost:3000 öffnen.

## KI-Anbindung

Die Route `app/api/chat/route.ts` erwartet eine OpenAI-kompatible Chat-Completions-API:
- `AI_API_URL`: vollständige Chat-Completions-URL des Anbieters
- `AI_API_KEY`: geheimer Schlüssel (nur serverseitig, niemals mit `NEXT_PUBLIC_`)
- `AI_MODEL`: Modellname

Ohne diese Angaben läuft die Oberfläche, aber es werden noch keine echten KI-Antworten erzeugt. Prüfe vor der Nutzung die kostenlosen Limits und Datenschutzbedingungen des gewählten Anbieters.

## Nächste Ausbaustufen

- Authentifizierung und Nutzerkonten
- Persistenter Chatverlauf und Memory mit Datenbank
- Datei-Upload und Dokumentensuche
- Web-Recherche mit Quellen
- Sprach-Ein- und Ausgabe
- Rate-Limits, Missbrauchsschutz und Datenschutz-/Löschfunktionen

## Kostenloser Betrieb

Lokale Entwicklung kostet nichts. Für eine öffentliche Cloud-Veröffentlichung können kostenlose Hosting- und Datenbank-Tarife genutzt werden, deren Limits und Bedingungen sich ändern können. Ein kostenloser Tarif garantiert keine unbegrenzte Nutzung. API-Aufrufe können Kosten verursachen.
