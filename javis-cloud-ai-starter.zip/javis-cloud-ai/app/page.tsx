'use client';

import { FormEvent, useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hallo! Ich bin JAVIS. Was kann ich heute für dich erledigen?" }
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  async function send(e: FormEvent) {
    e.preventDefault();
    const prompt = input.trim();
    if (!prompt || busy) return;
    const next = [...messages, { role: "user" as const, content: prompt }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Anfrage fehlgeschlagen.");
      setMessages([...next, { role: "assistant", content: data.reply }]);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unbekannter Fehler";
      setMessages([...next, { role: "assistant", content: `Hinweis: ${message}` }]);
    } finally { setBusy(false); }
  }

  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><span className="orb">✦</span><span>JAVIS</span></div>
      <button className="newChat" onClick={() => setMessages([{role:"assistant",content:"Neuer Chat gestartet. Was liegt an?"}])}>＋ Neuer Chat</button>
      <div className="sideLabel">WORKSPACE</div>
      <div className="navItem active">◈　Chat</div>
      <div className="navItem">▤　Dateien <small>Bald</small></div>
      <div className="navItem">⌕　Recherche <small>Bald</small></div>
      <div className="navItem">⚙　Einstellungen <small>Bald</small></div>
      <div className="sideBottom"><span className="statusDot"/> System bereit <span className="version">v0.1</span></div>
    </aside>
    <section className="main">
      <header><div><div className="eyebrow">PERSÖNLICHER KI-ASSISTENT</div><h1>Was machen wir heute?</h1></div><div className="online"><i/> ONLINE</div></header>
      <div className="chat">
        {messages.length === 1 && <div className="welcome"><div className="bigOrb">✦</div><h2>Ich bin <span>JAVIS</span>.</h2><p>Deine Ideen. Deine Aufgaben. Ein intelligenter Assistent.</p><div className="suggestions"><button onClick={()=>setInput("Erkläre mir, wie du funktionierst.")}>Wie funktionierst du?</button><button onClick={()=>setInput("Hilf mir, ein Projekt zu planen.")}>Projekt planen</button><button onClick={()=>setInput("Fasse ein Thema verständlich zusammen.")}>Thema zusammenfassen</button></div></div>}
        <div className="messages">{messages.slice(messages.length === 1 ? 1 : 0).map((m,i)=><div className={`message ${m.role}`} key={i}><div className="avatar">{m.role === "assistant" ? "✦" : "DU"}</div><div><div className="who">{m.role === "assistant" ? "JAVIS" : "DU"}</div><p>{m.content}</p></div></div>)}
        {busy && <div className="message assistant"><div className="avatar">✦</div><div><div className="who">JAVIS</div><p className="typing">Denkt nach…</p></div></div>}</div>
      </div>
      <form className="composer" onSubmit={send}><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Schreib JAVIS eine Nachricht…" /><button disabled={busy || !input.trim()} aria-label="Senden">↑</button></form>
      <div className="disclaimer">JAVIS kann Fehler machen. Prüfe wichtige Informationen.</div>
    </section>
  </main>;
}
