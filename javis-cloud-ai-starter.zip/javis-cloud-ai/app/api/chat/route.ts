import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const { messages } = await request.json();
  const apiKey = process.env.AI_API_KEY;
  const apiUrl = process.env.AI_API_URL;
  const model = process.env.AI_MODEL;

  if (!apiKey || !apiUrl || !model) {
    return NextResponse.json({
      error: "Die Chat-Oberfläche ist bereit. Für echte KI-Antworten muss zuerst ein kostenloser oder eigener KI-Anbieter in .env.local eingerichtet werden. Siehe README."
    }, { status: 503 });
  }

  try {
    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ model, messages, temperature: 0.7 })
    });
    const data = await upstream.json();
    if (!upstream.ok) return NextResponse.json({ error: "Der KI-Anbieter hat die Anfrage abgelehnt." }, { status: upstream.status });
    const reply = data.choices?.[0]?.message?.content ?? data.output_text ?? "Keine Antwort erhalten.";
    return NextResponse.json({ reply });
  } catch {
    return NextResponse.json({ error: "Der KI-Dienst ist gerade nicht erreichbar." }, { status: 502 });
  }
}
